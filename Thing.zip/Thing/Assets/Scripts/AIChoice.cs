﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ScissorsPaperRock
{
    public static class AIOption
    {
        public static UNIT theAIChosenOption;
        public static void start()
        {
            System.Random rnd = new System.Random(); // Makes the random class.
            int AISelect = rnd.Next(0, 3);
            {
                if (AISelect == 0)
                    theAIChosenOption = UNIT.SCISSORS; // I don't think enums from UnitData.cs AREN'T BEING REFERENCED!
                else if (AISelect == 1)
                    theAIChosenOption = UNIT.PAPER; //If true, this essentially means that this is doing nothing.
                else
                    theAIChosenOption = UNIT.ROCK; 
                // In theory, this code SHOULD select one of the three enums in UnitData.cs and keep the selected option on hand.
            }
        }
    }
}

// The aim of this is to have the AI randomly select from either scissors, paper or rock and keep the 
// selected option handy so it can be compared to the player's selected option in WhoWins.cs