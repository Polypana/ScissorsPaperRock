﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using System.Linq;
using ScissorsPaperRock;

namespace ScissorsPaperRock
{
    public class SelectRock : MonoBehaviour, IPointerClickHandler
    {
        public UNIT thePlayerChosenOption; // warning CS0414: The field 'SelectRock.thePlayerChosenOption' is assigned but its value is never used
        public void OnPointerClick(PointerEventData pointerEventData) 
        {
            Debug.Log("You selected rock!");
            thePlayerChosenOption = UNIT.ROCK;
        }
    }
}

// When you click on rock, it should note that you have selected rock, save this info, and keep it on hand for later.
// It should also make it so that you cannot click on another sprite to change your selection,
// although perhaps the game will compare fast enough that this isn't an issue.