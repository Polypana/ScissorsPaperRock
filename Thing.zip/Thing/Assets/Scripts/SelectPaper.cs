﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using System.Linq;
using ScissorsPaperRock;

namespace ScissorsPaperRock
{
    public class SelectPaper : MonoBehaviour, IPointerClickHandler
    {
        public UNIT thePlayerChosenOption; // warning CS0414: The field 'SelectPaper.thePlayerChosenOption' is assigned but its value is never used
        // THIS DOESN'T MAKE SENSE, I'M USING IT IN WHOWINS.CS?!
        public void OnPointerClick(PointerEventData pointerEventData)
        {
            Debug.Log("You selected paper!");
            thePlayerChosenOption = UNIT.PAPER;
        }
    }
}

// I feel as though this process could be simplified by having all 3 player options in 1 piece of code,
// But this also might just further complicate something I've worked so hard to make "work".