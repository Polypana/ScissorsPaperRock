﻿/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using System.Linq;
using ScissorsPaperRock;

namespace ScissorsPaperRock
{
    UNIT thePlayerChosenOption;
    public class PlayerSelect : MonoBehaviour, IPointerClickHandler
    {
        public void OnPointerClick(PointerEventData pointerEventData)
        {
            Debug.Log("You selected rock!");
            thePlayerChosenOption = UNIT.ROCK;
        }
    }
}*/


// This is basically a huge chunk of code to determine what the player selected!
// I'm not sure whether or not I want to use this or not! It'll be left commented out until I decide to use it!