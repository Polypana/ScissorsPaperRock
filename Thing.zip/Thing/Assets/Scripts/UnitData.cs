﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace ScissorsPaperRock
{
    public enum UNIT
    {
        SCISSORS,
        PAPER,
        ROCK
    }
}

// This is UnitData.cs

// The aim of this is to create the three options (scissors, paper or rock) so they can be referenced elsewhere!
// Scissors beats paper, paper beats rock, rock beats scissors.
// I don't believe for a damn second these enums are being referenced.