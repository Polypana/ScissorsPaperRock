﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using System.Linq;

namespace ScissorsPaperRock
{
    public class WhoWins
    {
        public static void Start()
        {
            if (thePlayerChosenOption == UNIT.SCISSORS) // Error The name 'thePlayerChosenOption' does not exist in the current context
            {
                if (AIChoice.theAIChosenOption == UNIT.SCISSORS) // error CS0103: The name 'theAIChosenOption' does not exist in the current context
                {
                    Debug.Log("The game is a tie!");
                }
                else if (AIChoice.theAIChosenOption == UNIT.PAPER) // error CS0103: The name 'theAIChosenOption' does not exist in the current context
                {
                    Debug.Log("You win!");
                }
                else
                {
                    Debug.Log("You lose!");
                }
            }
            else if (thePlayerChosenOption == UNIT.PAPER) // error CS0103: The name 'thePlayerChosenOption' does not exist in the current context
            {
                if (AIChoice.theAIChosenOption == UNIT.SCISSORS) // error CS0103: The name 'theAIChosenOption' does not exist in the current context
                {
                    Debug.Log("You lose!");
                }
                else if (AIChoice.theAIChosenOption == UNIT.PAPER) // error CS0103: The name 'theAIChosenOption' does not exist in the current context
                {
                    Debug.Log("The game is a tie!");
                }
                else
                {
                    Debug.Log("You win!");
                }
            }
            else
            {
                if (AIChoice.theAIChosenOption == UNIT.SCISSORS) // error CS0103: The name 'theAIChosenOption' does not exist in the current context
                {
                    Debug.Log("You win!");
                }
                else if (AIChoice.theAIChosenOption == UNIT.PAPER) // error CS0103: The name 'theAIChosenOption' does not exist in the current context
                {
                    Debug.Log("You lose!");
                }
                else
                {
                    Debug.Log("The game is a tie!");
                }
            }
        }
    }
}