﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using System.Linq;
using ScissorsPaperRock;

namespace ScissorsPaperRock
{
    public class SelectScissors : MonoBehaviour, IPointerClickHandler
    {
        public UNIT thePlayerChosenOption; // warning CS0414: The field 'SelectScissors.thePlayerChosenOption' is assigned but its value is never used
        public void OnPointerClick(PointerEventData pointerEventData)
        {
            Debug.Log("You selected scissors!");
            thePlayerChosenOption = UNIT.SCISSORS; // I don't think the enums are being referenced either.
        }
    }
}